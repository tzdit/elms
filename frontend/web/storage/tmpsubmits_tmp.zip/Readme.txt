Assignment submits download information 
------------------------------------------